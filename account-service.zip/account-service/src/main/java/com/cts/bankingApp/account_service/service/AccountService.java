package com.cts.bankingApp.account_service.service;

import com.cts.bankingApp.account_service.exception.AccountNotFoundException;
import com.cts.bankingApp.account_service.model.Account;
import com.cts.bankingApp.account_service.repository.AccountRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service

public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Account getAccountById(int id) throws AccountNotFoundException {
        return accountRepository.findById(id)
                .orElseThrow(() -> new AccountNotFoundException("Account with ID " + id + " not found"));
    }

    @Transactional
    public Account createAccount(Account account) {
//        account.setCreateTimestamp(LocalDateTime.now());
//        account.setUpdateTimestamp(LocalDateTime.now());
        return accountRepository.save(account);
    }

    public Account updateAccount(int id, Account accountDetails) throws AccountNotFoundException {
        Account existingAccount = getAccountById(id);
        existingAccount.setName(accountDetails.getName());
        existingAccount.setType(accountDetails.getType());
        existingAccount.setBalance(accountDetails.getBalance());
        existingAccount.setRoi(accountDetails.getRoi());
        existingAccount.setActive(accountDetails.isActive());
        existingAccount.setUpdateTimestamp(LocalDateTime.now());
        return accountRepository.save(existingAccount);
    }

    public void deleteAccount(int id) {
        accountRepository.deleteById(id);
    }

    public Account deposit(int id, double amount) throws AccountNotFoundException {
        Account account = getAccountById(id);
        account.setBalance(account.getBalance() + amount);
        account.setUpdateTimestamp(LocalDateTime.now());
        return accountRepository.save(account);
    }

    public Account withdraw(int id, double amount) throws AccountNotFoundException {
        Account account = getAccountById(id);
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            account.setUpdateTimestamp(LocalDateTime.now());
        } else {
            throw new IllegalArgumentException("Insufficient balance for withdrawal");
        }
        return accountRepository.save(account);
    }
}
