package com.cts.notification_service.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class FundTransferEvent {
    private int sourceAccountId;
    private int targetAccountId;
    private double amount;
    private String description;
    private LocalDateTime transferTimestamp;
}
