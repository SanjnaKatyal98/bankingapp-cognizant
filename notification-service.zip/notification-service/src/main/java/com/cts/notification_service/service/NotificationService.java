package com.cts.notification_service.service;

import com.cts.notification_service.model.FundTransferEvent;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    public void sendFundTransferNotification(FundTransferEvent event) {
        // Logic to send notification (could be email, SMS, etc.)
        System.out.println("Notification sent for Fund Transfer: ");
        System.out.println("Source Account: " + event.getSourceAccountId());
        System.out.println("Target Account: " + event.getTargetAccountId());
        System.out.println("Amount: " + event.getAmount());
        System.out.println("Description: " + event.getDescription());
    }
}
