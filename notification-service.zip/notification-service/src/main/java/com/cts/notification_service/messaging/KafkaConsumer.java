package com.cts.notification_service.messaging;

import com.cts.notification_service.model.FundTransferEvent;
import com.cts.notification_service.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
    @Autowired
    private final NotificationService notificationService;

    public KafkaConsumer(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @KafkaListener(topics = "fund-transfer-topic", groupId = "banking_group")
    public void listen(FundTransferEvent event) {
        notificationService.sendFundTransferNotification(event);
    }
}
