package com.cts.transaction_service.model;

public enum TransactionType {
    CREDIT, DEBIT
}
