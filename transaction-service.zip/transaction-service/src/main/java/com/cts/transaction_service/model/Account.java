package com.cts.transaction_service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;
@Entity

public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String type; // Savings, Current, Loan
    private double balance;
    private double roi;  // Rate of Interest (for savings or loan accounts)
    private boolean active;
    private LocalDateTime createTimestamp;
    private LocalDateTime updateTimestamp;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }

    public double getRoi() { return roi; }
    public void setRoi(double roi) { this.roi = roi; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public LocalDateTime getCreateTimestamp() { return createTimestamp; }
    public void setCreateTimestamp(LocalDateTime createTimestamp) { this.createTimestamp = createTimestamp; }

    public LocalDateTime getUpdateTimestamp() { return updateTimestamp; }
    public void setUpdateTimestamp(LocalDateTime updateTimestamp) { this.updateTimestamp = updateTimestamp;
    }
}
