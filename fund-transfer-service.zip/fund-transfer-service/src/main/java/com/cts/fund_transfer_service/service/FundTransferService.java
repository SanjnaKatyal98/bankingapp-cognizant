package com.cts.fund_transfer_service.service;

import com.cts.fund_transfer_service.messaging.KafkaProducer;
import com.cts.fund_transfer_service.model.FundTransfer;
import org.springframework.stereotype.Service;

@Service
public class FundTransferService {
    private final KafkaProducer kafkaProducer;

    public FundTransferService(KafkaProducer kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    public void transferFunds(FundTransfer fundTransfer) {
        // Send fund transfer details to Kafka
        kafkaProducer.sendMessage(fundTransfer);
    }
}
