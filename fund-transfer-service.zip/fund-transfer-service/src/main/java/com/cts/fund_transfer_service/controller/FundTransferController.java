package com.cts.fund_transfer_service.controller;

import com.cts.fund_transfer_service.model.FundTransfer;
import com.cts.fund_transfer_service.service.FundTransferService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/fundTransfers")
public class FundTransferController {

    private final FundTransferService fundTransferService;

    public FundTransferController(FundTransferService fundTransferService) {
        this.fundTransferService = fundTransferService;
    }

    @PostMapping
    public String initiateFundTransfer(@RequestBody FundTransfer fundTransfer) {
        fundTransferService.transferFunds(fundTransfer);
        return "Fund Transfer initiated successfully!";
    }
}
