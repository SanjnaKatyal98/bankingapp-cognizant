package com.cts.fund_transfer_service.messaging;


import com.cts.fund_transfer_service.model.FundTransfer;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducer {
    private static final String TOPIC = "fund-transfer-topic";
    private final KafkaTemplate<String, FundTransfer> kafkaTemplate;

    public KafkaProducer(KafkaTemplate<String, FundTransfer> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(FundTransfer fundTransfer) {
        kafkaTemplate.send(TOPIC, fundTransfer);
    }
}
