package com.cts.fund_transfer_service.repository;

import com.cts.fund_transfer_service.model.FundTransfer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FundTransferRepository extends JpaRepository<FundTransfer, Integer> {

}
