package com.cts.fund_transfer_service.messaging;

import com.cts.fund_transfer_service.model.FundTransfer;
import com.cts.fund_transfer_service.repository.FundTransferRepository;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
    private final FundTransferRepository fundTransferRepository;

    public KafkaConsumer(FundTransferRepository fundTransferRepository) {
        this.fundTransferRepository = fundTransferRepository;
    }

    @KafkaListener(topics = "fund-transfer-topic", groupId = "banking_group")
    public void listen(FundTransfer fundTransfer) {
        // Save fund transfer into the database
        fundTransferRepository.save(fundTransfer);
    }
}
