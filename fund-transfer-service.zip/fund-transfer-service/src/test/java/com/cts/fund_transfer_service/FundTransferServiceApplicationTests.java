package com.cts.fund_transfer_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundTransferServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
